export interface JwtPayload {
  sub: string;
}
